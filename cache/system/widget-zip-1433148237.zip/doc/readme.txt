Kod wstawienia na stronie:
{{W name=nextPrev parent=$page->parentId position=$page->position}}