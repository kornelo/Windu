<?php /*windu.org model*/
Class mapsGoogleController extends widgetMainController
{		
	public function run() {
		$data = "Example Content";	
		return array("content" => $data);
	}
}
?>