<?php /*windu.org model*/
Class slideLikeBoxController extends widgetMainController
{		
	public function run() {
		$data = "Example Content";	
		return array("content" => $data);
	}
}
?>
